export const categories = {
  Cars: ["Cars"],

  Bikes: ["Motorcycles", "Scooters", "Bicycles"],

  Furniture: [
    "Sofa & Dining",
    "Beds & Wardrobes",
    "Home Decor & Garden",
    "Kids Furniture",
    "Other Household Items",
  ],

  Fashion: ["Men", "Women", "Kids"],

  Pets: ["pets"],

  Electronics: [
    "Cameras & Lenses",
    "Games & Entertainment",
    "Fridges",
    "Computer Accessories",
    "Hard Disks, Printers & Monitors",
    "ACs",
    "Washing Machines",
  ],
  Sports: ["sport"],

  Mobiles: ["Mobile"],
};
