const iconData = [
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Oliver",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Jack",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Sophia",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Noah",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Ava",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Liam",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Mia",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Ethan",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Isabella",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Lucas",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Amelia",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Logan",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Harper",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Daniel",
];

export default iconData;

// export default iconData;
