
/**
 * MyListings.jsx
 * Seller dashboard page
 */
import './MyListings.css';

export default function MyListings() {
  return (
    <div>
      {/* MyListings content */}
    </div>
  );
}
