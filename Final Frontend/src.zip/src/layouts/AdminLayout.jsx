
/**
 * AdminLayout.jsx
 * Layout wrapper
 */
export default function AdminLayout() {
  return (
    <div>
      {/* AdminLayout content wrapper */}
    </div>
  );
}
